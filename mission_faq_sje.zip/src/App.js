import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import Landing_SJE from './components_sje/Landing_SJE';
import Faq_SJE from './components_sje/Faq_SJE';

function App() {
  return (
    <div>
      <Router>
        <Route path="/sje" component={Landing_SJE}/>
        <Route path="/faq_sje" component={Faq_SJE}/>
      </Router>
    </div>
  );
}

export default App;