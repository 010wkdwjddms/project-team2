import React from 'react';
import {Link} from 'react-router-dom';
import '../css_sje/landing_sje.css';
import Container from 'react-bootstrap/Container'
import 'animate.css';

function Landing_SJE() {
  return (
    <div id='landing_sje'>
      <Container>
        <div className='landing_content'>
          <Link to="/faq_sje">
            <h1 className='animate__animated animate__fadeIn' style={{ animationDuration: '700ms' }}>Colons:D</h1>
            <p className='animate__animated animate__fadeIn' style={{ animationDuration: '700ms' }}>당신의 모든 여행을 함께하는</p>
          </Link>
        </div>
      </Container>
      <img src="images/landing_sje.jpg" alt="landing"/>
    </div>
  );
}

export default Landing_SJE;