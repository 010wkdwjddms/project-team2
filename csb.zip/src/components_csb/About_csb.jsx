import React from 'react';
import '../css/About_csb.css';
import Navbar_csb from './Navbar_csb'; // Navbar_csb 컴포넌트를 import합니다.
import Footer_csb from './Footer_csb';

function About_csb() {
  return (
    <div >
      <Navbar_csb /> 
          <div className='h2_about'>우리 기관에 대해</div>
          <img src="/resource_csb/images/family.jpg" className="a_about" /> {/* 로고 이미지를 삽입합니다. */}
          <div className='txt_about'>
            우리 기관은 공공의 이익을 위해 다양한 서비스를 제공하는 기관입니다. 우리는 지속 가능한 발전과 지역 사회의 번영을 목표로 합니다.
            <br /><br />
            우리의 주요 목표는 투명성, 책임성, 그리고 공정성을 기반으로 시민들에게 높은 품질의 서비스를 제공하는 것입니다. 
            </div>
            {/* <Footer_csb /> */}
    </div>
  );
}

export default About_csb;