import React from 'react';
import { Link } from 'react-router-dom';
import '../css/LandingPage_csb.css'; // CSS 파일을 import합니다.

function LandingPage_csb() {
    return (
        <div className="landing-page">
            <video autoPlay loop muted className="background-video">
                <source src="/resource_csb/videos/government.mp4" type="video/mp4" />
            </video>
            <div className="overlay">
                <Link to="/main_csb" className="link-text">csb_page로 이동</Link>
            </div>
        </div>
    );
}

export default LandingPage_csb;
