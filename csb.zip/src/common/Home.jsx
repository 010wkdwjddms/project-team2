import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div>
      <h1>Welcome to Mission00</h1>
      <ul>
        <li>
          <Link to="/csb">최승빈</Link>
        </li>
        <li>
          <Link to="/kgj">김국진</Link>
        </li>
        <li>
          <Link to="/khs">김희선</Link>
        </li>
        <li>
          <Link to="/jnr">장나라</Link>
        </li>
        <li>
          <Link to="/lya">이영애</Link>
        </li>
      </ul>
    </div>
  );
};

export default Home;
