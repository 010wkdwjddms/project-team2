$(function(){
    // 변수에 담기
    let oneDepth = $('#header .gnb > li'), 
        twoDepth = oneDepth.children('.twoD'), 
        thrBtn = twoDepth.find('.thrBt'), 
        gnbBg = $('#header .gnbBg'),
        leftArea = $('#header .leftArea');

    // oneDepth에 마우스가 올라가면
    oneDepth.mouseenter(function(){
        $(this).addClass('on');
        twoDepth.show();
        gnbBg.show();
        leftArea.show();
        console.log('마우스엔터')
    })/* 마우스올라가면 끝 */

    // oneDepth에 마우스가 떠나가면 
    oneDepth.mouseleave(function(){
        $(this).removeClass('on');
        twoDepth.hide();
        gnbBg.hide();
        leftArea.hide();
        console.log('마우스떠남')
    })/* 마우스떠나가면 끝 */

    
    let orgH = gnbBg.height(),
        longH = gnbBg.height() + 70;

    thrBtn.click(function(){
        if( $(this).hasClass('on') ){
            $(this).removeClass('on');
            $(this).next('.thrD').hide();
            gnbBg.css( 'height' , orgH );
        }else{
            $(this).addClass('on');
            $(this).next('.thrD').show();
            gnbBg.css( 'height' , longH );  
        }
    })/* thrBtn 끝 */

    let openBt = $('.mHeader .menuBtn'),
        mMArea = $('.mMenuArea'),
        closeBt = mMArea.find('.closeBt'),
        oneD = $('.gnbArea').children('.oneD'),
        twoD = $('.gnbArea').children('.twoD'),
        thrBt = twoD.children('.thrBt'),
        thrD = twoD.children('.thrD');

    openBt.click(function(){
        mMArea.animate({'left' : '0'},600);
    })

    closeBt.click(function(){
        mMArea.animate({'left' : '-100%'},600);
    })

    oneD.click(function(){
        twoD.slideUp();
        oneD.removeClass('on')
        // 클릭한 oneD 자기자신 this의 다음요소인 twoD가 보인다 :visible / 안보인다 :hidden 
        // 에 일치하느냐?? is()
        // :visible을 ! 부정을 했기때문에 안보인다면 이 되는겁니다.
        if( !$(this).next('.twoD').is(':visible') ){
            $(this).next('.twoD').slideDown();
            $(this).addClass('on');
        }
    });/* oneD 끝 */

    thrBt.click(function(){
        $(this).next().slideToggle();
        $(this).toggleClass('on');
    })/* thrBt 끝 */

    let mainCon1LI = $('.mainCon1List > li'),
        mainCon1Bg = $('.mainCon1Bg > div');

    console.log(mainCon1LI);
    console.log(mainCon1Bg);

    mainCon1LI.each(function( idx ){
        //$(this).mouseenter(function(){});
        //$(this).mouseleave(function(){});

        $(this).hover(function(){
            mainCon1Bg.eq(idx).stop().fadeIn(600);
        } , function(){
            mainCon1Bg.eq(idx).stop().fadeOut(300);
        })
    }) /* 전시영역 배경이미지 교체 끝 */

   let topBtn= $('.topBtn');
   topBtn.click(function (ev){
    $('html').animate({'scrollTop':0},800,'easeOutElastic')
   })

    //윈도우 스크롤되면 애니메이션
    $(window).scroll(function(){
        
    })


})/* ready 끝 */