import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import Accordion from 'react-bootstrap/Accordion';
import '../css/mdy.css'; // 상대 경로 수정

const FAQ_MDY = () => {
  useEffect(() => {
    // script.js 파일을 동적으로 로드
    const script = document.createElement('script');
    script.src = './resource_mdy/js/script.js';  // script.js 파일의 경로
    script.async = true;
    document.body.appendChild(script);

    // 컴포넌트 언마운트 시 스크립트 제거
    return () => {
      document.body.removeChild(script);
    };
  }, []);


  return (
    <div className="wrapperW">
      <div id="util">
        <div className="container">
          <div className="right">
            <div className="links">
              <a href="#">롯데월드 어드벤처</a>
              <a href="#">아이스링크</a>
            </div>
            <div className="login">
              <a href="#">Login</a>
            </div>
          </div>
        </div>
      </div>
      <div id="header">
        <div className="container">
          <h1><a href="#"><img src="./resource_mdy/images/logo.png" alt="롯데월드민속박물관" /></a></h1>
          <div className="gnbArea">
            <ul className="gnb">
              <li>
                <a href="#">이용안내</a>
                <div className="twoD">
                  <ul>
                    <li><a href="#">박물관 소개</a></li>
                    <li><a href="#">관람안내</a></li>
                    <li><a href="#">대관안내</a></li>
                    <li><a href="#">오시는길</a></li>
                    <li>
                      <a href="#" className="thrBt">부대시설</a>
                      <div className="thrD">
                        <ul>
                          <li><a href="#">저자거리</a></li>
                          <li><a href="#">전통혼례</a></li>
                          <li><a href="#">민속기념품점</a></li>
                        </ul>
                      </div>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <a href="#">전시</a>
                <div className="twoD">
                  <ul>
                    <li><a href="#">상설전시</a></li>
                    <li><a href="#">특별전시</a></li>
                  </ul>
                </div>
              </li>
              <li>
                <a href="#">교육프로그램</a>
                <div className="twoD">
                  <ul>
                    <li>
                      <a href="#">역사교육</a>
                      <div className="thrD">
                        <ul>
                          <li><a href="#">프로그램</a></li>
                        </ul>
                      </div>
                    </li>
                    <li><a href="#">전통공예체험</a></li>
                  </ul>
                </div>
              </li>
              <li>
                <a href="#">소통·소식</a>
                <div className="twoD">
                  <ul>
                    <li><a href="#">새소식</a></li>
                    <li><a href="#">교육후기</a></li>
                    <li><a href="#">포토갤러리</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">이용문의</a></li>
                  </ul>
                </div>
              </li>
            </ul>
            <div className="leftArea">
                <img src="./resource_mdy/images/gnb_time_icon.png" alt="롯데월드민속박물관" className="clock"/>
              <p className="tit">운영시간</p>
              <dl>
                <dt>평일</dt>
                <dd>11:00 ~ 19:00</dd>
                <dt>주말/공휴일</dt>
                <dd>11:00 ~ 20:00</dd>
              </dl>
            </div>
          </div>
        </div>
        <div className="gnbBg"></div>
      </div>
      {/* 모바일 헤더 */}
      <div className="mHeader">
        <div>
          <a href="#" className="menuBtn"><img src="./resource_mdy/images/m_gnb_btn.png" alt="메뉴열기" /></a>
          <h1 className="logo"><img src="./resource_mdy/images/logo.png" alt="롯데월드민속박물관" /></h1>
        </div>
      </div>
      <div className="mMenuArea">
        <div className="top">
          <a href="#" className="loginBt">로그인</a>
          <a href="#" className="closeBt"><img src="./resource_mdy/images/m_close_btn.gif" alt="메뉴닫기" /></a>
        </div>
        <div className="links">
          <a href="#" className="lotteworld">롯데월드어드벤처</a>
          <a href="#" className="rink">아이스링크</a>
        </div>
        <div className="gnbArea">
          <a href="#" className="oneD">이용안내</a>
          <div className="twoD">
            <a href="#">박물관소개</a>
            <a href="#">관람안내</a>
            <a href="#">대관안내</a>
            <a href="#">오시는 길</a>
            <a href="#" className="thrBt">부대시설</a>
            <div className="thrD">
              <a href="#">저자거리</a>
              <a href="#">전통혼례</a>
              <a href="#">민속기념품점</a>
            </div>
          </div>
          <a href="#" className="oneD">전시</a>
          <div className="twoD">전시 서브메뉴작성</div>
        </div>
      </div>
      <div className='wrapper'>
        <div className="container">
          <h2 className="faqT">FAQ</h2>
            <div className="qnaTop">
              <div>
                 <img src="./resource_mdy/images/qnaTop_bg.jpg" alt="qna" className="QnaBP" />
              </div>
              <p className="txt"> 
                  <p className="em">롯데월드 민속박물관을 이용하시는 손님들께서 자주 찾으시는 질문과 답변들을 안내합니다.<br/></p>
                  궁금하신 질문을 클릭하시면, 해당하는 답변을 바로 보실 수 있습니다. <br/>
                  항상 친절하고 정확한 답변을 위해 노력하는 롯데월드 민속박물관이 되겠습니다.<br/>
              </p>     
            </div>
          <Accordion defaultActiveKey="100" className="qnaList">
            <Accordion.Item eventKey="0">
              <Accordion.Header>
              <span className="titP"><img src="./resource_mdy/images/qna_list_icon.png" alt="q" /></span>
                <p className="tit">
                  <span >체험교실 운영시간은 언제인가요?</span>
                </p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP"><img src="./resource_mdy/images/qna_answer_icon.png" alt="a" /></span>
                <p className="answerDiv">
                  <span >매일 오후 5시부터 입니다.</span>
                </p>
              </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="1">
              <Accordion.Header>
              <span className="titP"><img src="./resource_mdy/images/qna_list_icon.png" alt="q" /></span>
                <p className="tit">단체관람인 경우 예약을 해야 하나요?</p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP"><img src="./resource_mdy/images/qna_answer_icon.png" alt="a" /></span>
                <div className="answerDiv">
                  단체는 15인 이상입니다.<br />
                  쾌적한 관람을 위해 사전 예약을 통해 관람 인원을 조절하고 있습니다.<br />
                  동시간대 최대 수용 인원은 300명입니다.<br /><br />
                  도시락 등 음식물 섭취를 원하실 경우 별도의 장소를 제공해 드립니다.<br /><br />
                  예약 문의 02) 411 - 4764
                </div>
              </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="2">
              <Accordion.Header>
              <span className="titP"><img src="./resource_mdy/images/qna_list_icon.png" alt="q" /></span>
                <p className="tit">전시해설 프로그램이 있나요?</p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP"><img src="./resource_mdy/images/qna_answer_icon.png" alt="a" /></span>
                <div className="answerDiv">
                  <p>롯데월드 민속박물관은 현재 전시해설 프로그램을 운영하고 있지 않습니다.<br />
                    전시해설을 원하실 경우<br />
                    개인 : 교육프로그램 &quot;왁자지껄! 살아있는 박물관&quot; 또는 &quot;히스토리아! 시간탐험대&quot;를 신청해 주시기 바랍니다.<br />
                    단체 : 교육프로그램 &quot;역사탐험대&quot; 또는 &quot;뮤지엄트래블러&quot;를 신청해 주시기 바랍니다.<br /><br />
                    문의 02) 411 - 4764
                  </p>
                </div>
              </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="3">
              <Accordion.Header>
              <span className="titP"><img src="./resource_mdy/images/qna_list_icon.png" alt="q" /></span>
                <p className="tit">전시관을 돌아보는 데 소요 시간이 얼마나 되나요?</p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP"><img src="./resource_mdy/images/qna_answer_icon.png" alt="a" /></span>
                <div className="answerDiv">
                  약 1시간 가량 소요됩니다.<br /><br />
                  선사시대부터 조선시대까지 전시주제와 관련된 유물 및 모형으로 구성되어 있고, 전시실 중간에 다양한 전통체험 공간이 마련되어 있습니다.
                </div>
              </Accordion.Body>
            </Accordion.Item>
          </Accordion>
        </div>
        <p className="link">
          <Link to="/main">메인으로 Go!</Link> <br />
          <Link to="/mdy">랜딩페이지로 바로가기</Link>
        </p>
      </div>
      
      <div id="footer">
        <div className="container">
          <div className="top">
            <div className="links">
              <a href="#">롯데월드 소개</a>
              <a href="#">기업제휴 및 입점문의</a>
              <a href="#">이용약관</a>
              <a href="#" className="cRed">개인정보처리방침</a>
              <a href="#">사이트맵</a>
            </div>
          </div>
          <div className="bottom">
            <div className="left">
              <div>
                <p>서울특별시 송파구 올림픽로 240 호텔롯데 롯데월드 | 대표자 : 최홍훈</p>
                <p>사업자등록번호 : 219-85-00014 통신판매업신고번호 : 송파 제5513호 전화 : 1661-2000</p>
              </div>
              <p className="copyright">COPYRIGHT 2018 LOTTEWORLD. ALL RIGHTS RESERVED.</p>
            </div>
            <div className="familySite">
              <select>
                <option value="">계열사 관련 사이트</option>
                <option value="">LOTTE Family</option>
                <option value="">롯데웰프드</option>
                <option value="">롯데칠성음료(음료BG)</option>
              </select>
            </div>
          </div>
        </div>
        <div className="topBtn">
          <button type="button">
            <img src="images/top_btn.png" alt="위로가기" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default FAQ_MDY;
