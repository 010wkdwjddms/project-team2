import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Home from "./common/Home";
import Landing_MDY from "./components_mdy/Landing_MDY";
import FAQ_MDY from "./components_mdy/FAQ_MDY";
import CompanyInfo_MDY from "./components_mdy/CompanyInfo_MDY";
// bootstrap css를 app.js에 넣어야함 

import 'bootstrap/dist/css/bootstrap.css'; 

function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/mdy" component={Landing_MDY} />
          <Route path="/company-mdy" component={CompanyInfo_MDY} />
          <Route path="/faq-mdy" component={FAQ_MDY} />
        
          
        </Switch>
      </div>
    </Router>
  );
}

export default App;
