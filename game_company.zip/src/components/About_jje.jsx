import React from 'react';
import Container from 'react-bootstrap/Container';
import ReactPlayer from 'react-player';
import '../css/About_jje.css';

function About_jje() {
    return (
        <div className='background'>
            <Container>
                <div className='player'>
                    <ReactPlayer
                        url='https://youtu.be/ZHhqwBwmRkI?si=CCdWzWdPDnCroDa4'
                        playing={true}
                        muted={true}
                        controls={true}
                        loop={true}
                        width='100%'
                        height='100%'
                    />
                </div>
            </Container>

            <h1 className='riot'>라이엇 게임즈는 세계에서 가장 플레이어 중심적인 게임 회사가 되기 위해 노력하고 있습니다</h1>
            <br />
            <h3>
                라이엇 게임즈는 플레이어 입장에서 더 나은 게임과 경험을 만들고자 2006년에 설립되었습니다. 2009년 출시한 데뷔작 리그 오브 레전드는 세계에서 가장 많이 플레이하는 PC 게임의 반열에 올랐습니다. 이후 해를 거듭하며 발로란트, 전략적 팀 전투, 레전드 오브 룬테라, 리그 오브 레전드: 와일드 리프트 등을 출시했습니다. 라이엇의 게임은 세계에서 손꼽을 만큼 인지도가 높은 e스포츠 종목이며 매년 수백만 명의 팬이 보는 리그 오브 레전드 월드 챔피언십, 발로란트 챔피언스 같은 대회가 한 해의 대미를 장식합니다. 그 밖에 음악과 코믹 도서, 보드게임, 에미상을 받은 애니메이션 시리즈 아케인 등 다양한 프로젝트로 라이엇의 IP를 확장했습니다.
            </h3>
            <br /><br /><br />
        </div>
    );
}

export default About_jje;
