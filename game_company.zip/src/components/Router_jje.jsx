import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Header_jje from './Header_jje';
import Footer_jje from './Footer_jje';
import About_jje from './About_jje';
import QnA_jje from './QnA_jje';

const Router_jje = () => (
  <div className='app app-container'>
  <div className="navbar">
      
      </div>
  <Router>
<Header_jje />
<Switch>
    <Route path="/about_jje" component={About_jje}></Route>
    <Route path="/qna_jje" component={QnA_jje}></Route>


</Switch>
        <Footer_jje />
      </Router>
    </div>
  
  );
export default Router_jje;