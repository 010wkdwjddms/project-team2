import React from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import ReactPlayer from 'react-player'
import '../css/home_mjh.css';

function Home_mjh() {
    return (
        <div className='home_wrapper'>
               <Link to="/qna_mjh" className='link'>QnA로 이동</Link>
            <div className='playerContainer'>
                <ReactPlayer className='player' iframe width='1080px' height='570px' playing={true}  url='https://www.youtube.com/watch?v=8PWWdrlT3q4'/>
            </div>
        </div>
    );
}

export default Home_mjh;