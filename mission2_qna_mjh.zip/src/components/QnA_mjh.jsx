import React from 'react';
import '../css/qna_mjh.css';
import Accordion from 'react-bootstrap/Accordion';

function QnA_mjh() {
    return (
        <div className='wrapper'>
            <div className='topImg'>
            </div>
            <div className='help'>
                <span className='imgContent'>고객센터</span>
            </div>
            <div className='search-bar'>
                <input className='input' type="text" name="searchBox" placeholder='검색어를 입력하세요' />
                <div className='searchIcon'>
                    <img src="../icons_mjh/search_icon_mjh.svg" alt="search" />
                </div>
            </div>
            <section className='menu1'>
                <a className='qna' href="">QnA</a>
                <a href="">1:1문의</a>
                <a href="">복구문의</a>
                <a href="">보안</a>
                <a href="">원격지원</a>
                <a href="/mjh">home</a>
            </section>
            <h3><strong>QnA</strong></h3>
            <div className='accordionWrapper'>
                <Accordion >
                    <Accordion.Item  eventKey="0">
                        <Accordion.Header className='accordion-header' >건의사항 문의 방법을 알려주세요.</Accordion.Header>
                        <Accordion.Body className='accordion-body'>
                            불편 사항이나 개선이 필요하다 생각되시는 부분이 있을경우 <br />
                            위 메뉴의 <strong>1:1 문의</strong>를 통해 문의 접수 부탁드립니다.
                        </Accordion.Body>
                    </Accordion.Item>
                    <Accordion.Item eventKey="1">
                        <Accordion.Header>휴대폰 인증이 계속 실패해요.</Accordion.Header>
                        <Accordion.Body>
                            <strong>1. 고객님 명의의 아이디가 맞는지 확인해주세요.</strong>
                            <br /><br />
                            ‘아이디의 명의’와 ‘본인 인증 수단의 명의자’가 다른 경우,<br />
                            본인 인증에 실패할 수 있으니<br />
                            가족 또는 지인 명의로 가입한 아이디는 아닌지 확인해주세요<br />
                            <br />
                            <strong>2. 휴대폰 문제로 인해 인증이 어려울 수 있어요.</strong> <br />
                            휴대폰 인증이 실패하는 현상은 아래와 같은 이유로 나타날 수 있습니다. <br />
                            <br />
                            만약, 위 안내로도 해결되지 않아 인증이 어려우시다면 1:1문의 부탁 드립니다. <br />
                            <br />
                            <strong>하나,</strong> 본인인증 시 입력한 정보가 잘못된 경우 <br />
                            → 본인인증 시 선택하는 "통신사"를 비롯하여 "이름", "생년월일" <br />
                            그리고 "휴대폰 번호"를 잘못 입력한 것은 아닌지 확인 바랍니다. <br />
                            <br />
                            <strong>둘,</strong> 휴대폰 명의가 다른 경우 <br />
                            → 인증을 시도하는 ID의 가입자 정보와 다른 휴대폰으로는 <br />
                            본인인증이 되지 않고 있습니다. <br />
                            <br />
                            인증에 이용하신 휴대폰 가입자 정보를 확인해 주시길 바랍니다. <br />
                            (ID에 등록되어 있는 번호라도 명의가 다를 시 인증이 되지 않습니다.) <br />

                            <strong>셋,</strong> 휴대폰이 법인 명의로 되어 있는 경우 <br />
                            → 법인 명의로 되어 있는 휴대폰으로는<br />
                            개인 ID 본인인증이 되지 않고 있습니다. <br />
                            <br />
                            <strong>넷,</strong> 휴대폰이 정지되었거나 소액결제가 차단된 경우 <br />
                            → 정지되었거나 소액결제가 차단된 휴대폰으로는 인증이 어렵습니다. <br />
                            통신사에 문의하여 해제 후 인증 시도 바랍니다.
                        </Accordion.Body>
                    </Accordion.Item>
                    <Accordion.Item eventKey="2">
                        <Accordion.Header>아이디 찾기</Accordion.Header>
                        <Accordion.Body>
                            로그인이 어렵거나 휴대폰 혹은 신용/체크카드로 ID를 찾으시려면 <br />
                            아래 링크를 클릭하여 본인인증 후 ID를 찾아주세요. <br />
                            <a href="">[ID 찾기 바로가기]</a> <br />
                            <br />
                            만약, 본인인증에 어려움이 있으시다면, <br />
                            <strong>1:1 문의</strong>를 통하여 도움을 드릴 수 있습니다.
                        </Accordion.Body>
                    </Accordion.Item>
                    <Accordion.Item eventKey="3">
                        <Accordion.Header>비밀번호 찾기</Accordion.Header>
                        <Accordion.Body>
                            <strong>비밀번호 분실의 경우</strong> <br />
                            로그인 화면 비밀번호 찾기에서 본인인증 후 비밀번호 변경하여 로그인이 가능합니다. <br />
                            <br />
                            <strong>본인확인이 어려운 경우</strong> <br />
                            1:1문의를 이용하여 비밀번호를 찾으실 수 있도록 도와드립니다. <br />

                        </Accordion.Body>
                    </Accordion.Item>
                    <Accordion.Item eventKey="4">
                        <Accordion.Header>이용제한 해제</Accordion.Header>
                        <Accordion.Body>
                            이용제한 해제 방법 <br /><br />

                            1. 본인인증 수단이 있는 경우 <br />
                            - 보호를 위해 설정된 일부 이용제한의 경우 <strong>본인인증</strong>을 거쳐 해제하실 수 있습니다. <br />
                            <br />
                            2. 본인인증 수단이 없는 경우 <br />
                            - 본인인증 수단이 없으시다면 <strong>1:1문의</strong>를 통해 가입자 분의 마이핀 접수 시<br />
                            본인확인을 거쳐 보다 상세한 안내를 도와드리겠습니다. <br />
                            <br />
                            * 이용제한 유형에 따라 해제가 어려운 케이스가 있는 만큼, <br />
                            본인인증 후에도 해제되지 않는다면 자세한 확인을 위해 1:1문의 부탁드립니다. <br />
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>
            </div>
        </div>
    );
}


export default QnA_mjh;