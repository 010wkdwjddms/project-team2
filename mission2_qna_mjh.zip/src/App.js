import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import QnA_mjh from './components/QnA_mjh';
import Home_mjh from './components/Home_mjh';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div>
      <Router>
        <Route path="/mjh" component={Home_mjh}/>
        <Route path="/qna_mjh" component={QnA_mjh}/>
      </Router>      
    </div>
  );
}

export default App;